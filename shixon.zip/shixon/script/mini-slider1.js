mini_right.onclick = go_right;

setInterval("go_right()",5000);

var f = 0;

function go_right(){
	if (f > -1152) {
		f -= 192;
		mini_main.style.left = f + "px";
	} 
	else if (f <= -1152) {
		f = 0;
		mini_main.style.left = f;
	}
}

mini_left.onclick = function(){
	if (f < 0) {
		f += 192;
		mini_main.style.left = f + "px";
	} 
	else if (f >= 0) {
		f = -1152;
		mini_main.style.left = f + "px";
	}
}