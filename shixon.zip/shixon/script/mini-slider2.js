mini_right2.onclick = move_right;

setInterval("move_right()",5000);

var h = 0;

function move_right(){
	if (h > -1152) {
		h -= 192;
		mini_main2.style.left = h + "px";
	} 
	else if (h <= -1152) {
		h = 0;
		mini_main2.style.left = h;
	}
}

mini_left2.onclick = function(){
	if (h < 0) {
		h += 192;
		mini_main2.style.left = h + "px";
	} 
	else if (h >= 0) {
		h = -1152;
		mini_main2.style.left = h + "px";
	}
}