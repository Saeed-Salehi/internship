right.onclick = go_to_right;

setInterval("go_to_right()",5000);

var m = 0;

function go_to_right(){
	if (m > -300) {
		m -= 100;
		main.style.left = m + "%";
	} 
	else if (m == -300) {
		m = 0;
		main.style.left = m;
	}
}

left.onclick = function(){
	if (m < 0) {
		m += 100;
		main.style.left = m + "%";
	} 
	else if (m >= 0) {
		m = -300;
		main.style.left = m + "%";
	}
}

function fill(i){
	main.style.left = -100 * (i-1) + "%"; 
}

/* jq */

$(".circles").click(function(){
	$(".circles").removeClass("bg-b").addClass("bg-w");
	$(this).removeClass("bg-w").addClass("bg-b");
})