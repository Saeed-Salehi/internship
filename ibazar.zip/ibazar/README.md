# ibazzar_landing

Ibazzar Landing page
HTML5 + CSS3 + Js

## Colors

Background: `#f9f9f9ff`  
Green button: `#ccffaaff`  
Green button text: `#225500ff`  
Levels .No: `#ccffaa8e`  
Level step text: `#ccccccff`  
